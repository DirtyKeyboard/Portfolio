public class EmergencyRoom
{
	private Heap<Patient> list;
	
	public EmergencyRoom()
	{
		list = new Heap<Patient>();
	}
	
	public void checkIn(Patient p)
	{
		list.add(p);
	}
	
	public void admit()
	{
		if (list.size() !=0)
		{
			Patient ad = list.remove(list.size()-1);
			System.out.println(ad+" admitted.");
		}
		else
			System.out.println("No patients left to admit!");
		
	}
}
