import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

public class EmergencyRoomDemo
{
	public static void main(String[] args) throws InterruptedException
	{
		EmergencyRoom eRoom = new EmergencyRoom();
		Patient p1 = new Patient("Michael Rafferdy", LocalDate.of(2006, 3, 27), Severity.THREE);
		Patient p2 = new Patient("John Jones", LocalDate.of(2003, 1, 23), Severity.TEN);
		Patient p3 = new Patient("Petr Yan", LocalDate.of(2012, 4, 5), Severity.SEVEN);
		Patient p4 = new Patient("Zachary Smalls", LocalDate.of(2000, 11, 1), Severity.EIGHT);
		Patient p5 = new Patient("Waldo Biggums", LocalDate.of(1999, 8, 8), Severity.SEVEN);
		eRoom.checkIn(p1);
		TimeUnit.SECONDS.sleep(1);
		System.out.println("Patient 1 Checked in...");
		eRoom.checkIn(p2);
		TimeUnit.SECONDS.sleep(1);
		System.out.println("Patient 2 Checked in...");
		eRoom.checkIn(p3);
		TimeUnit.SECONDS.sleep(1);
		System.out.println("Patient 3 Checked in...");
		eRoom.checkIn(p4);
		TimeUnit.SECONDS.sleep(1);
		System.out.println("Patient 4 Checked in...");
		eRoom.checkIn(p5);
		TimeUnit.SECONDS.sleep(1);
		System.out.println("Patient 5 Checked in...");
		TimeUnit.SECONDS.sleep(1);
		System.out.println("--Admitting All Patients--");
		eRoom.admit();
		eRoom.admit();
		eRoom.admit();
		eRoom.admit();
		eRoom.admit();
	}
}
