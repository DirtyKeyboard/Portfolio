import java.util.*;
public class Heap<T extends Comparable<T>>
{
	//Head = Index0
	private ArrayList<T> heap;
	public Heap()
	{
		heap = new ArrayList<>();
	}
	
	public void add (T o)
	{
		heap.add(o);
		sort();
	}
	
	public boolean remove(T o)
	{
		if (heap.size()>0)
		{
			heap.remove(o);
			sort();
			return true;
		}
			else
		return false;
				
	}
	
	public T remove(int index)
	{
		if (heap.size()!=0)
		{
			T rem = heap.get(index);
			heap.remove(index);
			sort();
			return rem;
		}
			else
			{
				T rem = null;
				return rem;
			}
				
	}
	
	public int size()
	{
		return heap.size();
	}
 
	
	private void sort()
	{
		Collections.sort(heap);
	}
	
	@Override
	public String toString()
	{
		String ret = "";
		for (int i = 0; i < heap.size(); i++)
		{
			
			ret += heap.get(i).toString()+"\n";
		}
		return ret;
	}
}
