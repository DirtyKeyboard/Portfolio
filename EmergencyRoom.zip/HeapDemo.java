public class HeapDemo
{
	public static void main(String[] args)
	{
		Heap<Integer> test = new Heap<Integer>();
		for (int i = 0; i < 20; i++)
		{
			Integer addd = new Integer((int)(Math.floor(Math.random()*99)));
			test.add(addd);
		}
		System.out.println(test);
	}
}
