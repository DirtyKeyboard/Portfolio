import java.time.*;
public class Patient implements Comparable<Patient>
{
	private String name;
	private LocalDate dob;
	private Severity sev;
	public LocalTime arrivalTime;
	
	public Patient(String name, LocalDate dob, Severity sev)
	{
		this.name = name;
		this.dob = dob;
		this.sev = sev;
		arrivalTime = LocalTime.now();
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public Severity getSev() {
		return sev;
	}
	public void setSev(Severity sev) {
		this.sev = sev;
	}
	
	public LocalTime getArrivalTime()
	{
		return arrivalTime;
	}
	
	@Override
	public String toString()
	{
		return name + "\n  DOB=" + dob + "\n  severity="+sev+"\n  arrivalTime="+arrivalTime;
	}
	
	@Override
	public int compareTo(Patient p)
	{
		int comp = sev.compareTo(p.getSev());
		if (comp > 0)
			return 1;
		else if (comp < 0)
			return -1;
		else if (dob.compareTo(p.getDob()) > 0)
			return -1;
		else if (dob.compareTo(p.getDob()) < 0)
			return 1;
		else if (arrivalTime.compareTo(p.getArrivalTime()) > 0)
			return 1;
		else if (arrivalTime.compareTo(p.getArrivalTime()) < 0)
			return -1;
		else
			return 0;
	}
	
}
