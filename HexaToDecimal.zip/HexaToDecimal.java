package School;
/*
 * Write a function that receives a string containing a 32-bit hexadecimal integer. 
 * The function must return the decimal integer value of the hexadecimal integer. 
 * Demonstrate your function with a driver program.
 * ---------
 * Andrew Hawileh
 * COSC 2325
 * 09/01/2022
 */
public class HexaToDecimal
{
	public static void main(String[] args)
	{
		/*
		 * F3DDD = 998877
		 * 
		 * 
		 */
		String custom = "3A";
		System.out.println(custom+" --> " + hexToDec(custom));
		System.out.println("3039 --> " + hexToDec("3039"));
		System.out.println("7B25CD --> " + hexToDec("7B25CD"));
	}
	public static int hexToDec(String hex)
	{
		//0-9, A-F
		//A:10, B:11, etc
		int ret = 0;
		int q = 0;
		for (int i = 0; i < hex.length(); i++)
		{
			try {
			q = Integer.parseInt(""+hex.charAt(i));
			ret += q*Math.pow(16, hex.length()-1-i);
			} catch (NumberFormatException e)
			{
				q = getNum(""+hex.charAt(i));
				ret += q*Math.pow(16, hex.length()-1-i);
			}
		}
		return ret;
	}
	public static int getNum(String x)
	{
		int a = 0;
		switch (x)
			{
		case "A": a=10; break;
		case "B": a=11; break;
		case "C": a= 12; break;
		case "D": a= 13; break;
		case "E": a= 14; break;
		case "F": a= 15;
			}
		return a;
	}
}

