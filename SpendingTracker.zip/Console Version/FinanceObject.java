import java.util.*;
import java.io.*;

public class FinanceObject implements Serializable
{
	private static final long serialVersionUID = 1L;
	//name price
	private ArrayList<String> storedNames;
	private Map<String, Double> data;
	public FinanceObject()
	{
		data = new TreeMap<String, Double>();
		storedNames = new ArrayList<String>();
	}
	
	public int size()
	{
		return data.size();
	}
	
	public void add(String name, Double price)
	{
		data.put(name.replace(" ", ""), price);
		storedNames.add(name.replace(" ", ""));
	}
	
	public ArrayList<String> getStoredNames()
	{
		return storedNames;
	}
	
	public double getPrice(String name)
	{
		return data.get(name);
	}
	
	public void remove(String name)
	{
		data.remove(name);
		storedNames.remove(name);
	}
	
	public boolean isEmpty()
	{
		return data.isEmpty();
	}
	
	public boolean find(String name)
	{
		if (data.containsKey(name))
			return true;
		else
			return false;
	}
	
	public String toString()
	{
		String ret = data.toString();
		return ret.substring(1, ret.length()-1).replace(" ", "").replace(",", "\n").replace("=", ": $");
	}
}