import java.util.*;
import java.io.*;
import java.text.*;


class FinanceProgram
{
	private DecimalFormat m = new DecimalFormat("###.##"); //print m.format(whatToFormat);
	private Scanner in;
	private double total; //monthly expenditures
	private double income; //monthly income
	private double remain; //monthly leftover
	private int choice;
	private FinanceObject budget = new FinanceObject();
	public FinanceProgram()
	{
		choice = 0;
		in = new Scanner(System.in);
		boolean done = false;
		while (!done)
		{
			try
			{
			System.out.print("Please input your monthly income: ");
			income = in.nextDouble();
			done=true;
			}
			catch (Exception e)	{in.nextLine();}
		}
		remain = income-total;
		total = 0;
		boolean finished = false;
		boolean programDone = false;
		
		while (!programDone)
		{
			while (!finished)
			{
			System.out.println("\nMonthly Expdentitures: $" + m.format(total));
			System.out.println("Remaining Monthly: $" + m.format(remain));
			System.out.println("[1] Add, [2] Budgeting, [3] Exact Budgeting, [4] Show Charges, [5] Remove a Charge, [6] Load dataFile.txt, [7] Exit");
			System.out.print("> ");
			try 
			{ 
				choice = in.nextInt();
				
				if (choice <= 0 || choice > 7)
					throw new Exception();
				finished=true;
			}
			catch (Exception e) { inputError(); }
			}

			programDone = choices();
			finished=false;
		}
	}
	
	private void inputError()
	{
		System.out.println("\nPlease double check inputs."); 
		System.out.println("Press enter to continue.");
		in.nextLine();
		in.nextLine();
	}
	private void p()
	{
		System.out.println("Press enter to continue.");
		in.nextLine();
		in.nextLine();
	}
	
	private boolean choices()
	{
		
		if (choice == 1) 
		{
			ArrayList<String> n = budget.getStoredNames();
			String name = ""; double price = 0;
			try
			{
				in.nextLine();
				System.out.print("Input item name: ");
				name = in.nextLine();
				System.out.print("Input item price: ");
				price = in.nextDouble();
				
				for (int i = 0; i < n.size(); i++)
				{
					if (name.equals(n.get(i)))
						throw new InputMismatchException();
				}
				
				budget.add(name, price);
				total+=price;
				remain-=price;
			}
			catch (InputMismatchException q) {System.out.println("Be careful! There is already an existing charge with that name."); System.out.println("Press enter to continue."); in.nextLine(); in.nextLine();}
			catch (Exception c) {inputError();}
		}
		else if (choice == 2)
		{
			if (remain < 0)
			{
				System.out.println("Sorry! You do not have enough money to be budgeting, you need to save over $" + m.format(remain*-1) + " before you start to budget.");
			}
			else
			{
				System.out.println("Here's your budget: \n" +
													"Save 5% : $" + m.format(remain*.05) + "/mo :: YTD: $" + ( m.format(remain*.05*12) )  +
													"\nSave 10% : $" + m.format(remain*.1) + "/mo :: YTD: $" + m.format((remain*.1)*12) + " (recommended)" +
													"\nSave 15% : $" + m.format(remain*.15) + "/mo :: YTD: $" + m.format((remain*.15)*12) + 
													"\nSave 25% : $" + m.format(remain*.25) + "/mo :: YTD: $" + m.format((remain*.25)*12) + 
													"\nSave 30% : $" + m.format(remain*.30) + "/mo :: YTD: $" + m.format((remain*.30)*12));
			}
			p();
			
		}
		else if (choice == 3)
		{
			if (remain < 0)
			{
				System.out.println("Sorry! You do not have enough money to be budgeting, you need to save over $" + remain*-1 + " before you start to budget.");
			}
			else
			{
				double percent;
				try {
				System.out.println("Input the % of money you'd like to save. [ex: 20.4]");
				System.out.print("> ");
				percent = in.nextDouble();
				percent /= 100;
				System.out.println("Save " + percent*100 + "% : $" + m.format(remain*percent) + "/mo :: YTD: $" + m.format((remain*percent)*12));
				} catch (Exception q) {inputError();}
			}
			p();
		}
		else if (choice == 4)
		{
			System.out.println(budget);
			p();
		}
		else if(choice == 5)
		{
			in.nextLine();
			System.out.println(budget+"\n\nWhich payment would you like removed? [by name]");
			System.out.print("> ");
			String name = in.nextLine();
			if (budget.find(name))
			{
				double removingPrice = budget.getPrice(name);
				budget.remove(name);
				remain+=removingPrice;
				total-=removingPrice;
			}
			else
			{
				System.out.println("That charge was not found :( please double check inputs.");
			}
			System.out.println("Press enter to continue.");
			in.nextLine();
		}
		else if (choice == 6) //total to 0, remain = income, update the 
		{
			try {
			boolean first = true;
			income=0;
			total=0;
			remain=0;
			budget = new FinanceObject();
			Scanner fileReader = new Scanner(new File("dataFile.txt"));
			while (fileReader.hasNextLine())
			{
				if (first)
				{
					income = Double.parseDouble(fileReader.nextLine());
					remain=income;
					first=false;
				}
				else
				{
					String name = fileReader.nextLine();
					double price = Double.parseDouble(fileReader.nextLine());
					remain-=price;
					total+=price;
					budget.add(name, price);
				}
			}
			System.out.println("Income: " + income);
			System.out.println(budget);
			fileReader.close();
			
			
			
			} 
			catch (Exception nfuioewfewhoui) {}
			System.out.println("Press enter to continue.");
			in.nextLine();
			in.nextLine();
		}
		else if(choice == 7)
		{
			System.out.println("Exiting...");
			p();
			return true;
		}
		return false;
	}
}	