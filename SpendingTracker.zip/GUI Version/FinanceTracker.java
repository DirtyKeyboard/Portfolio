public class FinanceTracker
{
	public static void main (String[] args)
	{
		new WindowFrame();
	}
}