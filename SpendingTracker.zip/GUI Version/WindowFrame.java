import javax.swing.*;
import java.util.*;
import java.awt.event.*;
import java.awt.*;
import java.text.*;
import java.io.*;

@SuppressWarnings("serial")
class WindowFrame extends JFrame implements ActionListener
{
	private static final String U = "admin";
	private static final String P = "password";
	private JTextField username;
	private JTextField password;
	public WindowFrame()
	{
		JPanel panel = new JPanel();
		JPanel r1 = new JPanel();
		JPanel r2 = new JPanel();
		JPanel r3 = new JPanel();
		
		panel.setLayout(new GridLayout(3, 2));
		JLabel user = new JLabel("Username: ");
		JLabel pass = new JLabel("Password: ");
		username = new JTextField(15);
		password = new JTextField(15);
		JButton login = new JButton("Login");
		login.addActionListener(this);
		password.setFont(new Font("Webdings", Font.PLAIN, 12));
		r1.add(user);
		r1.add(username);
		panel.add(r1);
		
		r2.add(pass);
		r2.add(password);
		panel.add(r2);
		
		r3.add(login);
		panel.add(r3);
		add(panel);
		setSize(350, 150);
		setTitle("Finance Manager :: Login");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setIconImage(new ImageIcon("C:\\Users\\andre\\Desktop\\Finance\\icon.jpg").getImage());
		setVisible(true);
	}
	public void disposeFrame()
	{
		dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
	}
	public void actionPerformed(ActionEvent e)
	{
		if (username.getText().equals(U) && password.getText().equals(P))
		{
			new FullFrame();
			disposeFrame();
		}
		
	}
}

@SuppressWarnings("serial")
class FullFrame extends JFrame implements ActionListener
{
	private JButton chargesText;
	private JButton add;
	private JButton rem;
	private JButton bud;
	private JButton exactBud;
	private JButton save;
	private JButton load;
	private JButton dsave;
	private double total;
	private double income;
	private double remain;
	private JLabel expen;
	private JLabel left;
	private FinanceObject budget = new FinanceObject();
	public FullFrame()
	{
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		boolean done = false;
		
		while (!done)
		{
			try {
			income = Double.parseDouble(JOptionPane.showInputDialog(null, "Please input your monthly income", "Income", JOptionPane.INFORMATION_MESSAGE));
			done=true;
			}
			catch (Exception e)	{}
		}
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); 
		addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent evnt)
					{
						 int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit", 0);
					        if (confirm == 0) {System.exit(0);}
					}
				}
		);
		setTitle("Finance Manager :: Main");
		remain = income-total;
		setIconImage(new ImageIcon("C:\\Users\\andre\\\\Desktop\\Finance\\icon.jpg").getImage());
		chargesText = new JButton("Show Charges");
		chargesText.addActionListener(this);
		JScrollPane scroll = new JScrollPane(chargesText);
		setSize(900, 600);
		JPanel panel = new JPanel();
		GridLayout lay = new GridLayout(2, 1);
		panel.setLayout(lay);
		
		panel.add(new JLabel("Monthly Income: $"+income));
		panel.add(scroll);
		expen = new JLabel("Monthly Expenditures $"+total);
		left = new JLabel("Leftover Monthly: $"+remain);
		JPanel dd = new JPanel();
		dd.setLayout(new GridLayout(1, 2));
		dd.add(expen);
		dd.add(left);
		setLayout(new BorderLayout());
		add(panel, BorderLayout.NORTH);
		add(dd, BorderLayout.CENTER);
		JPanel bt = new JPanel();
		//bt.setLayout();
		
		
		
		add = new JButton("Add Payment");
		bud = new JButton("Budgeting");
		exactBud = new JButton("Exact Budgeting");
		rem = new JButton("Remove Payment");
		save = new JButton("Save this Budget"); 
		load = new JButton("Load a Budget");
		dsave = new JButton("Delete Save");
		
		add.addActionListener(this);
		bud.addActionListener(this);
		exactBud.addActionListener(this);
		rem.addActionListener(this);
		save.addActionListener(this);
		load.addActionListener(this);
		dsave.addActionListener(this);
		
		bt.add(add);
		bt.add(bud);
		bt.add(exactBud);
		bt.add(rem);
		bt.add(save);
		bt.add(load);
		bt.add(dsave);
		
		
		add(bt, BorderLayout.SOUTH);
		total = 0;
		setVisible(true);
	}
	
	private void inputError()
	{
		JOptionPane.showMessageDialog(null, "Please double check your inputs", "Input Error", 0);
	}
	public void actionPerformed(ActionEvent e)
	{
		DecimalFormat m = new DecimalFormat("###.##");
		
		if (e.getSource() == add) 
		{
			String name = ""; double price = 0;
			try
			{
				name = JOptionPane.showInputDialog("Input Item Name");
				price = Double.parseDouble(JOptionPane.showInputDialog("Input Item Price"));
				budget.add(name, price);
				total+=price;
				remain-=price;
				expen.setText("Monthly Expenditures $"+total);
				left.setText("Leftover Monthly: $"+remain);
			} catch (Exception c) {inputError();}
		}
		else if (e.getSource() == bud)
		{
			if (remain < 0)
			{
				JOptionPane.showMessageDialog(null, "Sorry! You do not have enough money to be budgeting, you need to save over $" + remain*-1 + " before you start to budget.", "You're broke :(", 0);
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Here's your budget: \n" +
													"Save 5% : $" + m.format(remain*.05) + "/mo :: YTD: $" + ( m.format(remain*.05*12) )  +
													"\nSave 10% : $" + m.format(remain*.1) + "/mo :: YTD: $" + m.format((remain*.1)*12) + " (recommended)" +
													"\nSave 15% : $" + m.format(remain*.15) + "/mo :: YTD: $" + m.format((remain*.15)*12) + 
													"\nSave 25% : $" + m.format(remain*.25) + "/mo :: YTD: $" + m.format((remain*.25)*12) + 
													"\nSave 30% : $" + m.format(remain*.30) + "/mo :: YTD: $" + m.format((remain*.30)*12), "Budget", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		else if (e.getSource() == exactBud)
		{
			if (remain < 0)
			{
				JOptionPane.showMessageDialog(null, "Sorry! You do not have enough money to be budgeting, you need to save over $" + remain*-1 + " before you start to budget.", "You're broke :(", 0);
			}
			else
			{
				double percent;
				try {
				percent = Double.parseDouble(JOptionPane.showInputDialog(null, "Input the % of money you'd like to save. [ex: 20.4]", "Percentage", JOptionPane.INFORMATION_MESSAGE));
				percent /= 100;
				JOptionPane.showMessageDialog(null, "Save " + percent*100 + "% : $" + m.format(remain*percent) + "/mo :: YTD: $" + m.format((remain*percent)*12), "Exact Budget", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception q) {inputError();}
			}
		}
		else if (e.getSource() == chargesText)
		{
			JOptionPane.showMessageDialog(null, budget+"", "Charges List", JOptionPane.INFORMATION_MESSAGE);
		}
		else if(e.getSource() == rem)
		{
			String name = JOptionPane.showInputDialog(null, budget+"\n\nWhich payment would you like removed? [by name]", "Removal", JOptionPane.INFORMATION_MESSAGE);
			if (budget.find(name))
			{
				double removingPrice = budget.getPrice(name);
				budget.remove(name);
				remain+=removingPrice;
				total-=removingPrice;
				expen.setText("Monthly Expenditures $"+total);
				left.setText("Leftover Monthly: $"+remain);
			}
			else
			{
				JOptionPane.showMessageDialog(null, "That charge was not found :( please double check inputs.", "Error: Charge not found", 0);
			}
		}
		else if (e.getSource() == save)
		{
			try {
			String saveFile = JOptionPane.showInputDialog(null, "What would you like to save your file under?", "Save File", JOptionPane.INFORMATION_MESSAGE);
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(saveFile+".save"));
			oos.writeObject(budget);
			oos.close();
			JOptionPane.showMessageDialog(null, "Your file was successfully saved as \"" + saveFile + ".save\"", "Success!", 1);
			}
			catch (Exception egf)
			{
				JOptionPane.showMessageDialog(null, "There was a problem with this file name, please try naming your file something else", "Error: File Names", 0);
				egf.printStackTrace();
			}
		} 
		else if (e.getSource() == load) //total to 0, remain = income, update the 
		{
			try {
				String saveFile = JOptionPane.showInputDialog(null, "What file would you like to load?", "Load File", JOptionPane.INFORMATION_MESSAGE);
				ObjectInputStream oos = new ObjectInputStream(new FileInputStream(saveFile+".save"));
				budget = (FinanceObject)oos.readObject();
				oos.close();
				total = 0; //expends get added
				remain = income; //remain -= expen
				String context = budget.toString();
				context = context.replace(":", "");
				context = context.replace("$", "");
				Scanner reader = new Scanner(context);
				while (reader.hasNext())
				{
					reader.next();
					double pen = reader.nextDouble();
					reader.nextLine();
					pen+=total;
					remain-=pen;
				}
				reader.close();
			
				
				expen.setText("Monthly Expenditures $"+total);
				left.setText("Leftover Monthly: $"+remain);
				JOptionPane.showMessageDialog(null, "Your file was successfully loaded from \"" + saveFile + ".save\"", "Success!", 1);
				}
				catch (Exception egf)
				{
					JOptionPane.showMessageDialog(null, "There was a problem with this file name, please try naming your file something else", "Error: File Names", 0);
				}			
		}
		else if (e.getSource() == dsave)
		{
			
		}
	}
}	